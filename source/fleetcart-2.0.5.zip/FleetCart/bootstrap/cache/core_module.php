<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    1 => 'Modules\\Core\\Providers\\ModuleServiceProvider',
    2 => 'Modules\\Core\\Providers\\ThemeServiceProvider',
    3 => 'Modules\\Core\\Providers\\AssetServiceProvider',
    4 => 'Modules\\Core\\Providers\\SearchEngineServiceProvider',
    5 => 'Modules\\Core\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    1 => 'Modules\\Core\\Providers\\ModuleServiceProvider',
    2 => 'Modules\\Core\\Providers\\ThemeServiceProvider',
    3 => 'Modules\\Core\\Providers\\AssetServiceProvider',
    4 => 'Modules\\Core\\Providers\\SearchEngineServiceProvider',
    5 => 'Modules\\Core\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);