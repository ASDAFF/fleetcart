<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Coupon\\Providers\\CouponServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Coupon\\Providers\\CouponServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);