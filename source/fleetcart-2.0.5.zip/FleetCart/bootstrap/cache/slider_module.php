<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Slider\\Providers\\SliderServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Slider\\Providers\\SliderServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);