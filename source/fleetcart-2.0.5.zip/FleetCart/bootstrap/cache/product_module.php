<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    1 => 'Modules\\Product\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    1 => 'Modules\\Product\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);