<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Option\\Providers\\OptionServiceProvider',
    1 => 'Modules\\Option\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Option\\Providers\\OptionServiceProvider',
    1 => 'Modules\\Option\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);