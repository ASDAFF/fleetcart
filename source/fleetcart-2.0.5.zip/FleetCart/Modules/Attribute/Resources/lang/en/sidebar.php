<?php

return [
    'attribute_sets' => 'Attribute Sets',
    'attributes' => 'Attributes',
];
