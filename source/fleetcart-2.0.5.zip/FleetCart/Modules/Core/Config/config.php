<?php

return [
    'core_modules' => [
        'core',
        'support',
        'admin',
        'dashboard',
        'meta',
        'user',
        'workshop',
        'setting',
        'media',
        'meta',
        'page',
        'product',
        'translation',
    ],
];
