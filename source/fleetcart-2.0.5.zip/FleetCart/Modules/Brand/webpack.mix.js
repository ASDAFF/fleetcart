let mix = require('laravel-mix');

mix.js(`${__dirname}/Resources/assets/admin/js/main.js`, `${__dirname}/Assets/admin/js/brand.js`);
