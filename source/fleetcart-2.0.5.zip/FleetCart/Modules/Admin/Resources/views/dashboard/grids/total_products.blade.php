<div class="col-lg-3 col-md-6 col-sm-6">
    <div class="single-grid total-products">
        <h4>{{ trans('admin::dashboard.total_products') }}</h4>

        <i class="fa fa-cubes" aria-hidden="true"></i>
        <span class="pull-right">{{ $totalProducts }}</span>
    </div>
</div>
