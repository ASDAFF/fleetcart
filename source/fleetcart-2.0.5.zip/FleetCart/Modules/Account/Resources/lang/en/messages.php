<?php

return [
    'profile_updated' => 'Your profile has been updated.',
];
