<?php

return [
    'new_order_subject' => 'A new order has been placed',
    'new_order_text' => 'A new order has been placed. The order id is #:order_id',
    'view_order' => 'View Order',
    'if_you\’re_having_trouble' => 'If you’re having trouble clicking the "View Order" button, copy and paste the URL below into your web browser:',
];
